export const appSettings = {
  app_identifier: 'automated-testing',
  webuser: {
    username: 'automatedtesting@bettyblocks.com',
    password: 'automatedtesting@bettyblocks.com',
  },
};
